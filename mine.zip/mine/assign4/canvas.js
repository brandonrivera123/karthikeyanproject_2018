var canvas = document.querySelector("canvas");
canvas.width=1000;
canvas.height = 500;

var c = canvas.getContext("2d");

c.font="30px Georgia";
c.fillText("Figure 2.1", 25, 70);

c.font="15px Georgia";
c.fillText("The yellow icons represent light energy.",25, 100);
c.fillStyle = "gray";
c.fillRect(50,200,100, 50); //handle
c.beginPath(); //trapezoid
c.moveTo(160,200);
c.lineTo(195,180);
c.lineTo(195, 270);
c.lineTo(160, 250);
c.fill();
//c.fillRect(700, 180, 100, 90); //photodetector
c.beginPath();
c.arc(750, 225, 50, 0, Math.PI * 2, false);
    c.strokeStyle = "gray";
    c.stroke();
    c.fill();
//c.fillRect(160, 180, 35,90); //trapezoid to be

// text screw organizing my code lulz
c.fillStyle = "white";
c.fillRect(20,325,200, 50);
c.fillRect(300, 325, 300, 105);
c.fillRect(700, 325, 250, 100);

c.fillStyle = "gray";
c.font="15px Georgia";
var message = "A light source (LED/laser)";
c.fillText(message,25,345);
c.fillText("supplies the light energy.", 25, 360 );
c.fillText("The cables are made of fibers of glass. Each", 305, 345  );
c.fillText("fiber consists of two layers of glass. The", 305, 360)
c.fillText("different refractive indeces of those two ", 305, 375);
c.fillText("layers cause the light to bend and bounce in  ", 305, 390);
c.fillText("the inner core as it travels to the ", 305, 405);
c.fillText("photodetector.", 305, 420);
c.fillText("The photodetector will receive the ", 705, 345);
c.fillText("light and convert the light energy ", 705, 360);
c.fillText("into electric energy that the machine ", 705, 375);
c.fillText("will understand as bits.", 705, 390);


c.fillStyle = "black";
c.fillRect(150,200,10,50); //screwy top
c.fillRect(100,190,30,10); //button

c.beginPath();
c.arc(750, 225, 30, 0, Math.PI * 2, false);
    c.strokeStyle = "black";
    c.stroke();
    c.fill();

c.fillStyle = "yellow"; //heckin arrow
c.fillRect(225, 215, 20, 20)
c.beginPath();
c.moveTo(245,205);
c.lineTo(245,245);
c.lineTo(265, 224.5);
c.fill();

// -------------- CORES ---------------
c.fillStyle = "#AFC2D5";
c.fillRect(300, 180, 300, 90); //outer core



// --------------- CIRCLE --------------
var x = 310; //x coordinate of first circle 
var y = 225.5; //y coor
var dx = 1; //velocity
var dy = 1;
var radius = 10; //it's in good taste to make a variable for a number you use over and over

  


function animate() {
    requestAnimationFrame(animate);
    c.clearRect(300, 195, 300, 60);
    c.fillStyle = "#CCDDD3";
c.fillRect(300, 190, 300, 70); //inner core
    
c.beginPath();
    c.arc(x, y, radius, 0, Math.PI * 2, false);
    c.fillStyle = "yellow";
    c.strokeStyle = "yellow";
    c.stroke();
    c.fill();

    // travel to the end - X AXIS
    if (x + radius > 597){
        x = 310;
        y = 222.5;
    }

    // travel up and down - Y AXIS
    if(y + radius > 257 || y - radius <195){
        dy = -dy;
    }

    x += dx;
    y += dy;
    console.log("dude");
};

animate();

c.fillStyle = "#DFEFCA";
c.fillRect(735, 210, 30, 30);

c.fillStyle = "yellow"; //heckin arrow
c.fillRect(630, 215, 20, 20)
c.beginPath();
c.moveTo(650,205);
c.lineTo(650,245);
c.lineTo(670, 222.5);
c.fill();


console.log(canvas);