<html>
<head>
<link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
</head>

<body>
<center><h1> Contact List Manager </h1></center>
<?php
	session_start();

	if($_SESSION['username'] == "")
	{
		header("Location: index.php?error=2");
	}


		$username = $_SESSION["username"];
	echo "Current User: $username <br><br>";

	?>

<center>
<h2> Actions </h2>
<a href ="add.php"> Add a Contact </a> <br><br>
<a href ="modify.php"> Modify a Contact </a> <br><br>
<a href ="delete.php"> Delete a Contact </a>
</center>
<br><a href="logout.php">Log Out</a>


</body>
</html>