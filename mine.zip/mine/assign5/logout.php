<html>
<head>
<link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
</head>
<body>

<?php
        session_start();

        if($_SESSION['username'] == "")
        {
                header("Location: index.php?error=2");
        }


        $username = $_SESSION['username'];
        echo "Good-Bye, $username.";

	session_destroy();
?>
<br><a href='index.php'>Log In</a>
</body>
</html>
