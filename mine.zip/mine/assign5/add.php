<html>
<head>

<link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
<title> Add a New Contact </title>
<script>
function addContact(){

}
</script>
</head>

<body>

<?php
 session_start();
$username = $_SESSION["username"];
 echo "Current User: $username ";
?>

<h3>Create a New Contact</h3>

<form action='form.php' method='post'>
<table>
<tr>
	<td>First Name:</td><td><input type='text' name='firstName'></td>
	

</tr>

<tr>
<td>Last Name: </td> <td><input type='text' name='lastName'></td>
</tr>
<tr>
        <td>Email:</td><td><input type='text' name='email'></td>
</tr>
<tr>
        <td>Phone Number:</td><td><input type='text' name='phone'></td>
<td> Only the digits with no spaces between them.
</tr>
<tr>
<td><br></td>
</tr>
<tr>
<td></td>
	<td colspan='2'><input type='Submit' value='Add Contact'></td>
</tr>
</table>
</form>

<br>
<h3>List of Existing Contacts </h3>
<?php
	//Create reference to file
	//this part works
	$file_name = "information.dat";
	$fp = fopen($file_name, "r");

	//Write out the contents of the file
	echo "<ul>";
	while($line = fgets($fp))
	{
		$firstName = strtok($line, "|");  
		$lastName = strtok("|");
		$email = strtok("|");
		$phone = strtok("|");
		$today = strtok("|");
		

		echo "<li>$firstName $lastName</li>
		<ul>
		<li><a href='mailto:$email'>$email</a></li>
		<li>Phone: $phone</li>
		<li>Date Contact Created: $today</li> </ul>";
	

	}
	echo "</ul>";
	fclose($fp);
?>
</table>
<center><a href="http://139.62.210.151/~n01030245/cop4813/assign5/admin.php">Back to Menu</a></center>
</body>
</html>