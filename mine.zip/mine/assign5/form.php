<?php
	//Get the variables
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];

	//Get the current date
	$today = date('m.d.y');

	//Create file pointer
	$file_name = "information.dat";
	$fp = fopen($file_name, "a");

	//Write information to file
	fwrite($fp, "$firstName|$lastName|$email|$phone|$today\n");

	//Close file
	fclose($fp);

	//Server side redirect
	header("Location: add.php");
?>
