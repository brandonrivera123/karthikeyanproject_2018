<html>
<head>
<link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
<title>Modify</title>
</head>
<?php
 session_start();
$username = $_SESSION["username"];
 echo "Current User: $username ";
?>

<center>
<h1>Modify a Contact's Information</h1>
</center>
*** This page doesn't do anything.
<h3>Which contact would you like to modify?</h3>
<p>Enter both their first and last name.</p><br>
First name: <input type='text' name='first'><br><br>
Last name: <input type='text' name='last'><br><br>
<input type='Submit' value='Search for this Contact'>

<center><a href="http://139.62.210.151/~n01030245/cop4813/assign5/admin.php">Back to Menu</a></center>

</html>
