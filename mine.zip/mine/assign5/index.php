<html>
<head>

<title>Log In Page</title>
 <link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
</head>


<body>
<form action = "authentication.php" method ="post">
<center>
<h1> Welcome! </h1>
<h3> Please sign in. </h3>
</center>
<table>
<tr>
    <td> Username: </td>
<td> <input type = "text" name="username" id= "username"><br> </td>
</tr>
<tr>
    <td>Password: </td>
<td><input type="password" name="password"><br> </td>
</tr>

<tr>
<td></td>
<td> <input type="submit" id = "submitBtn" value="Log In"> </td>
</tr>
</table>
</form>


<?php
$error = $_GET["error"];
if($error == 1)
echo "Invalid credentials.";

elseif($error == 2)
echo "Please log in first.";
?>
</body>
</html>

