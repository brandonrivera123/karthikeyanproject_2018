<html>
<body>

<script language="javascript" type="text/javascript">
<!-- 
//Browser Support Code
function ajaxFunction(){
	var ajaxRequest;  // The variable that makes Ajax possible!
	
	try{
		// Opera 8.0+, Firefox, Safari
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		// Internet Explorer Browsers
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				// Something went wrong
				alert("Your browser broke!");
				return false;
			}
		}
	}
	// Create a function that will receive data sent from the server
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
			document.getElementById("output").innerHTML = ajaxRequest.responseText;
		}
	}
	
	var selection = document.myForm.listPersons.value;

	ajaxRequest.open("GET", "getData.php?selection=" + selection, true);
	ajaxRequest.send(null); 
}

//-->
</script>



<form name='myForm'>
<select name="listPersons" onChange="ajaxFunction()">
<?php

	$mysql_access = mysql_connect("localhost", "n00010608", "123#ERT#123");

	if (!$mysql_access)
	{
		echo "Connection failed.";
		exit;
	}

	mysql_select_db("n00010608");

	$query = "select personFirstName, personLastName, personID from Persons";

	$result = mysql_query($query);

	while ($record = mysql_fetch_array($result) ) {
		
		echo "<option value='$record[2]'>$record[0] $record[1]</option>";

	}

	mysql_close($mysql_access);

?>
</select>
</form>
<br><br>
<p id="output"></p>
</body>
</html>
