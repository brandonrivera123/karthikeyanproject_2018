// This is for index.html of Assignment 3, Some Calculator Thing

function calcSum(nums) {
    var sum = 0;
    for (var i = 0; i < nums.length; i++) {
        sum += nums[i];
    }
    return sum;
}

function calcMean(nums) {

    return truncate((calcSum(nums)) / nums.length);
}

function calcMedian(nums) {
    var length = nums.length;
    //test COMMENT OUT BELOW LATER !!
    //var median = 100; 
    nums.sort();

    if ((length % 2) === 0) {
        median = ((nums[length / 2 - 1] + nums[length / 2]) / 2);
    }
    else {
        median = (nums[(length - 1) / 2]);
    }
    return truncate(median);
}



//white flag
function calcMode(nums) {
   var modes = [];
   var count = []
   var x;
   var max = 0;
 
    for (var i = 0; i < nums.length; i += 1) {
        x = nums[i];
        count[x] = (count[x] || 0) + 1;
        if (count[x] > max) {
            max = count[x];
        }
    }
 
    for (i in count)
        if (count.hasOwnProperty(i)) {
            if (count[i] === max) {
                modes.push(Number(i));
            }
        }
 
    return modes;
}


function calcVariance(nums) {
    // n in this formula is the length of nums
    var firstPart = 0;
    var numerator = 0;
    var variance = 0;

    for (i = 0; i < nums.length; i++) {
        firstPart += Math.pow(nums[i], 2);
    }
    variance = (firstPart - (Math.pow(calcSum(nums), 2) / nums.length)) / (nums.length - 1)
    return truncate(variance);
}

function calcDeviation(nums) {
    var deviation = Math.sqrt(calcVariance(nums));
    return truncate(deviation);
}

function truncate(num) {
    return +(Math.round(num + "e+2") + "e-2");
}
