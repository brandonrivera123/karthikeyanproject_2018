<html>
<head>

<?php
	$error = $_GET['error'];
?>

<script>
	function deleteRecord()
	{
		document.myForm.action='delete.php';
		document.myForm.submit();
	}
        function changeRecord()
        {
                document.myForm.action='change.php';
                document.myForm.submit();
        }
</script>

<?php
		$mysql_access = mysql_connect('localhost','n01030245', 'pql>sql');

	if(!$mysql_access)
	{
		die('Could not connect: ' . mysql_error());
	}

	mysql_select_db('n01030245');

	$query = "SELECT * FROM Pokemon"; 
	$result = mysql_query($query, $mysql_access);
?>



<link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
<title> Starter Pokemon Database </title>


</head>

<body>
<center> <h1> Starter Pokemon Database </h1> 
<p>
This page will help you keep track of all your Starter Pokemon. You can even make up your own Starter Pokemon and add it to the database. </center>
</p>
<hr>

<p>
Please fill out all blanks and provide answers for all spaces in the form below.
</p>

<style>
    .form
        {
            width: 70%;
        }
    
            </style>

<!--**************** FORM PART ****************** -->

<form action= "add.php" method= "get">
<fieldset class="form">
<legend> Add New Pokemon </legend>

<table>
<tr>
 <td> *Pokemon Name: </td>
 <td><input type="text" name= "name"> </td>
</tr>

<tr>
 <td> *Pokemon Type: </td>
 <td><input type='radio' name='type' value='Fire'> Fire &nbsp
<input type='radio' name='type' value='Water'> Water &nbsp
<input type='radio' name='type' value='Grass'> Grass</td></tr>


<tr>
 <td> *Region of Origin: </td>
 <td><select id='region' name='region'>
                <option>Select one</option>
                <option value='Kanto'>Kanto</option>
                <br>
                <option value='Sinnoh'>Sinnoh</option>
	<br>
 <option value='Hoenn'>Hoenn</option>

                </select>
 </td>
</tr>

<tr>
 <td> *Favorite Poffin Flavor?: </td>
 <td><input type="text" name= "evolve"> </td>
</tr>

<tr>

 <td> *Role it Plays: </td>
 <td> 
	<input type='checkbox' name='roles' value='Battling'> Battling &nbsp
            <input type='checkbox' name='roles2' value='Breeding'> Breeding &nbsp
            <input type='checkbox' name='roles3' value='Contests'> Contests
</td>
</tr>

<tr>
<td></td>
	<td colspan ="2">
	<input type="Submit" value="Add">
</td>
</tr>

</table>
</fieldset>
</form>

<hr>

<form action= '' name='myForm' method='get'>
<?php
	echo "<h3> Current Pokemon Database </h3>";
	echo "<table border='1'>";
	echo "<tr>";
	echo "<th> --- </th>";
	echo "<th>Name</th>";
	echo "<th>Type</th>";
	echo "<th>Region</th>";
	echo "<th>Poffin</th>";
	echo "<th>Roles</th>";
	echo "</tr>";
	while($row = mysql_fetch_row($result))
	{
		$pokemonNumber = $row[0];
		$name = $row[1];
		$type = $row[2];
		$region = $row[3];
		$evolve = $row[4];
		$roles = $row[5];
		
		echo "<tr>";
		echo "<td><input type='radio' name='pokemonNumber' value='$pokemonNumber'></td>";
		echo "<td>$name</td>";
                echo "<td>$type</td>";
                echo "<td>$region</td>";
                echo "<td>$evolve</td>";
                echo "<td>$roles $roles2  $roles3</td>";
		echo "</tr>";		
	}

	echo "</table>";
	mysql_close($mysql_access);
?>
<br>
<input type='button' value='Change Record' onClick='changeRecord()'>
<input type='button' value='Delete Record' onClick='deleteRecord()'>
<br>
<br>
<hr>
<a href="../assign6/erd.html">ER Diagram</a>
</form>
</body>
</html>