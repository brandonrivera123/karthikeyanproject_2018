<?php
  $username = "n01030245";
  $password = "pql>sql";
  $dbName = "n01030245";
  $serverName = "localhost";	
  
  $dbConnect = new mysqli($serverName, $username, $password, $dbName);
  if ($dbConnect->connect_error){
    die("Connection to the server failed");
  }
 ?>