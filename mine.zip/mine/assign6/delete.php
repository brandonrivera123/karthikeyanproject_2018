<?php
	$pokemonNumber = $_GET['pokemonNumber'];

        $mysql_access = mysql_connect('localhost','n01030245', 'pql>sql');

        if(!$mysql_access)
        {
                die('Could not connect: ' . mysql_error());
        }

        mysql_select_db('n01030245');
	
	$query = "DELETE FROM Pokemon WHERE pokemonNumber= " . $pokemonNumber;

	echo $query;

	$result = mysql_query($query, $mysql_access);
	
	mysql_close($mysql_access);

	header('Location: index.php');

?>
