<?php
	
	$name = $_GET['name'];
        $type = $_GET['type'];
        $region = $_GET['region'];
        $evolve = $_GET['evolve'];
        $roles = $_GET['roles'];
	$roles2 = $_GET['roles2'];
	$roles3 = $_GET['roles3'];
	
	$mysql_access = mysql_connect('localhost','n01030245', 'pql>sql');

	if(!$mysql_access)
	{
		die('Could not connect: ' . mysql_error());
	}

	mysql_select_db('n01030245');

	$query = "INSERT INTO Pokemon (pokemonName, pokemonType, pokemonRegion, pokemonEvolve, pokemonRoles) VALUES ";
	$query = $query . "('$name', '$type', '$region', '$evolve', '$roles &nbsp $roles2 &nbsp $roles3')";
	

	$result = mysql_query($query, $mysql_access);

	mysql_close($mysql_access);

	header('Location: index.php');

?>
