<html>
<head>
<link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
<title> Change a Pokemon's Info </title>


<?php
	$pokemonNumber = $_GET['pokemonNumber'];

        $mysql_access = mysql_connect('localhost','n01030245', 'pql>sql');

        if(!$mysql_access)
        {
                die('Could not connect: ' . mysql_error());
        }

        mysql_select_db('n01030245');

	$query = "SELECT * FROM Pokemon WHERE pokemonNumber = " . $pokemonNumber;

	$result = mysql_query($query, $mysql_access);

        $row = mysql_fetch_row($result);
        
       $pokemonNumber = $row[0];
		$name = $row[1];
		$type = $row[2];
		$region = $row[3];
		$evolve = $row[4];
		$roles = $row[5];

	mysql_close($mysql_access);
?>
</head>
<body>

<form action='change_p.php' method='get'>
<h3> Change a Pokemon's Information </h3>
<p> You can make changes to any field of an existing Pokemon's information using the form below. </p>
<form action='change_p.php' method='get'>
<fieldset class="form">
<legend> Change <?php echo "$name's"; ?> Information </legend>

<table>
<tr>
 <td> *Pokemon Name: </td>
 <td><input type="text" name= "name" value='<?php echo $name; ?>'> </td>
</tr>

<tr>
 <td> *Pokemon Type: </td>
 <td>
<input type='radio' name='type' value='Fire'> Fire &nbsp
<input type='radio' name='type' value='Water'> Water &nbsp
<input type='radio' name='type' value='Grass'> Grass</td>
</tr>

<tr>
 <td> *Region of Origin: </td>
 <td><select id='region' name='region' >
                <option value = '<?php echo $region; ?>'>Currently: <?php echo $region; ?></option>
		<br>
                <option value='Kanto'>Kanto</option>
                <br>
                <option value='Sinnoh'>Sinnoh</option>
	<br>
 <option value='Hoenn'>Hoenn</option>

                </select>
 </td>
</tr>

<tr>
 <td> *Favorite Poffin: </td>
 <td><input type="text" name= "evolve" value='<?php echo $evolve; ?>'> </td>
</tr>

<tr>

 <td> *Role it Plays: </td>
 <td><input type="text" style="width: 20em;" name= "roles" value='<?php echo "$roles $roles2 $roles3"; ?>'readonly> </td>
</tr> 
<tr><td></td><td><input type='checkbox' name='roles' value='Battling'> Battling &nbsp
            <input type='checkbox' name='roles2' value='Breeding'> Breeding &nbsp
            <input type='checkbox' name='roles3' value='Contests'> Contests
</td>
</tr>

<tr>
<td></td>
	<td colspan ="2">
	<input type="Submit" value="Submit Changes" onClick='check()'>
</td>
</tr>

</table>
</fieldset>

<input type='hidden' name='pokemonNumber' value='<?php echo $pokemonNumber; ?>'>
</form>
</form>
</body>
</html>
