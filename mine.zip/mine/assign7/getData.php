<html>
<?php
        $pokemonNumber = $_GET['selection'];
	echo "<h3> Information: </h3>";
        $mysql_access = mysql_connect('localhost', 'n01030245', 'pql>sql'); 
        if (!$mysql_access)
        {
                echo "Connection failed.";
                exit;
        }
        mysql_select_db("n01030245");

        $query = "Select pokemonNumber, pokemonName, pokemonType, pokemonRegion, pokemonEvolve from Pokemon where pokemonNumber=" . $pokemonNumber;

        $result = mysql_query($query);
        $record = mysql_fetch_array($result);

        $pokemonNumber = $record[0];
	$name = $record[1];
	$type = $record[2];
	$region = $record[3];
	$poffin = $record[4];
	echo "Pokemon Name: $name <br>";
	echo "Favorite Poffin Flavor: $poffin <br>";
	echo "Region of Origin: $region <br>";


	mysql_close($mysql_access);

?>
<br>
<br>

Need to change something? <a href="http://139.62.210.151/~n01030245/cop4813/assign6/">Click here to go to the Database site.</a>
</html>



