<html>
<head>
 <link rel="stylesheet" type="text/css" href="http://139.62.210.151/~n01030245/cop4813/CSS.css">
<title> Wow! Amazing!</title>
</head>
<body>
<center><h2>View Some Good Ole Information!</h2></center>
<h3> Choose which Pokemon you would like to view information of. </h3>
<script language="javascript" type="text/javascript"> 
//Browser Support Code
function ajaxFunction(){
	var ajaxRequest;  // The variable that makes Ajax possible!
	
	try{
		// Opera 8.0+, Firefox, Safari
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		// Internet Explorer Browsers
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				// Something went wrong
				alert("Your browser broke!");
				return false;
			}
		}
	}
	// Create a function that will receive data sent from the server
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
			document.getElementById("output").innerHTML = ajaxRequest.responseText;
		}
	}
	
	var selection = document.myForm.listPersons.value;

	ajaxRequest.open("GET", "getData.php?selection=" + selection, true);
	ajaxRequest.send(null); 
}


</script>



<form name='myForm'>
<select name="listPersons" onChange="ajaxFunction()">

<?php

	$mysql_access = mysql_connect("localhost", "n01030245", "pql>sql");

	if (!$mysql_access)
	{
		echo "Connection failed.";
		exit;
	}

	mysql_select_db("n01030245");

	$query = "select pokemonName, pokemonType, pokemonNumber from Pokemon";

	$result = mysql_query($query);

	while ($record = mysql_fetch_array($result) ) {
		
		
	echo "<option value='$record[2]'>$record[0] $record[1]</option>";

	}

	mysql_close($mysql_access);

?>
</select>
</form>
<br><br>
<p id="output"></p>
</body>
</html>
