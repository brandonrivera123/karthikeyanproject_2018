function findSum(x)
{
	var sum = 0;
	for(var i = 0; i < x.length; i++)
	{
		sum += x[i];
	}
	return sum;
}
function findMean(x)
{
	return findSum(x)/x.length;
}
