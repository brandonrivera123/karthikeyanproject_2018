<?php
	//Get the variables
	$name = $_POST['name'];
	$city = $_POST['city'];
	$website = $_POST['website'];

	//Get the current date
	$today = date('m.d.y');

	//Create file pointer
	$file_name = "information.dat";
	$fp = fopen($file_name, "a");

	//Write information to file
	fwrite($fp, "$name|$city|$website|$today\n");

	//Close file
	fclose($fp);

	//Server side redirect
	header("Location: index.php");
?>
