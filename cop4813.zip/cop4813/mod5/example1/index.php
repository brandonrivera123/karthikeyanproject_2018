<html>
<body>
<h2>Sign My Guestbook!</h2>
<form action='sign.php' method='post'>
<table>
<tr>
	<td>Full Name:</td><td><input type='text' name='name'></td>
</tr>
<tr>
        <td>City:</td><td><input type='text' name='city'></td>
</tr>
<tr>
        <td>Website:</td><td><input type='text' name='website'></td>
</tr>
<tr>
	<td colspan='2'><input type='Submit' value='Sign'></td>
</tr>
</table>
</form>
<h2>People that have signed my guestbook!</h2>
<?php
	//Create reference to file
	$file_name = "information.dat";
	$fp = fopen($file_name, "r");

	//Write out the contents of the file
	echo "<ul>";
	while($line = fgets($fp))
	{
		$name = strtok($line, "|");
		$city = strtok("|");
		$website = strtok("|");
		$today = strtok("|");
		echo "<li><a href='$website'>$name</a> from $city was here on $today.";
	}
	echo "</ul>";
	fclose($fp);
?>
</table>
</body>
</html>
