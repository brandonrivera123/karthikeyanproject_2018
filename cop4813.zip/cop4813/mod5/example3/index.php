<html>
<body>
<form action='authenticate.php' method='post'>
<table>
<tr>
	<td>Username:</td><td><input type='text' name='username'></td>
</tr>
<tr>
        <td>Password:</td><td><input type='password' name='password'></td>
</tr>
<tr>
	<td colspan='2'><input type='Submit' value='Log In'></td>
</tr>
</table>
</form>
<?php
	$error = $_GET['error'];
	if($error == 1)
		echo "Invalid credentials.";
	elseif ($error == 2)
		echo "You must log in first.";
?>
</body>
</html>
