<?php
        session_start();

        if($_SESSION['username'] == "")
        {
                header("Location: index.php?error=2");
        }


        $username = $_SESSION['username'];
        echo "Good-Bye, $username.";

	session_destroy();
?>
<br><a href='index.php'>Log In</a>

