<?php   
        session_start();

        if($_SESSION['username'] == "")
        {
                header("Location: index.php?error=2");
        }


	$username = $_SESSION['username'];
	echo "Welcome, $username.";
?>
<br><a href='logout.php'>Log Out</a>

