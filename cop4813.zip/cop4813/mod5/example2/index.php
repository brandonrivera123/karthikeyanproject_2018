<form action="process.php" method="get">
Number 1: <input type="text" name="num1"><br>
Number 2: <input type="text" name="num2"><br>
<input type="Submit" value="Add Numbers">
</form>
