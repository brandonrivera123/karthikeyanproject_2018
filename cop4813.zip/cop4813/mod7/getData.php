<?php
        $personID = $_GET['selection'];

        $mysql_access = mysql_connect('localhost', 'n00010608', '123#ERT#123'); 
        if (!$mysql_access)
        {
                echo "Connection failed.";
                exit;
        }
        mysql_select_db("n00010608");

        $query = "Select * from Persons where personID=" . $personID;

        $result = mysql_query($query);
        $record = mysql_fetch_array($result);

        $personID = $record[0];
	$email = $record[1];
        $fName = $record[3];
        $lName = $record[2];
        $address = $record[4];
	$city = $record[5];
        $ficoScore = $record[6];


	echo "First Name: $fName <br>";
	echo "Last Name: $lName <br>";
	echo "Email: $email <br>";


	mysql_close($mysql_access);

?>



